//
//  DetailViewController.h
//  navDemo
//
//

#import <UIKit/UIKit.h>
//#import "MyDrawingView.h"

@interface DetailViewController : UIViewController

//declare your drawing view

@end
