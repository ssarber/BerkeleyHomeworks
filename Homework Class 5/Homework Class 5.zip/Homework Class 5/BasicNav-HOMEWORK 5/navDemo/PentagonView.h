//
//  PentagonView.h
//  DrawPentagon
//
//  Created by ssarber on 9/30/12.
//  Copyright (c) 2012 ssarber. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PentagonView : UIView

@end
